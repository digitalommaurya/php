<?php
require 'auth.php'; // the code you shared
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the message returned by the register function
    $message = register($_POST['username'], $_POST['password']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Student Registration</title>
  <style>
    <?php include 'style.css'; ?>
  </style>
</head>
<body>
  <div class="form-container">
    <h2>Register</h2>
    <?php if ($message): ?><p class="message"><?= $message ?></p><?php endif; ?>
    <form method="POST">
      <input type="text" name="username" placeholder="Username" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit">Register</button>
    </form>
    <p>Already have an account? <a href="login.php">Login</a></p>
  </div>
</body>
</html>
