<?php
session_start();

if(!isset($_SESSION['username']))
{

header("Location:error.php");

}
else 
{
	
	echo '
<!DOCTYPE html> 
<html> 
  
<head> 
    <title>PDF in HTML</title> 
</head> 
  
<body> 
<a href="welcome.php">Go to Main Page </a>
    <center> 
        <h1 style="color: green">Lecture 6</h1> 
        
        <object data= 
"lecture6.pdf#toolbar=0" 
                width="100%"
                height="800"> 
        </object> 
    </center> 
</body> 
  
</html>';

}?>
