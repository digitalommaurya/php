<?php
require 'db.php';

function register($username, $password) {
    global $pdo;

    // Check if the username already exists
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $count = $stmt->fetchColumn();

    if ($count > 0) {
        // Username already exists, handle the error
        return "Username is already taken. Please choose a different one.";
    }

    // If username doesn't exist, hash the password and insert the user
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'student')");
    
    if ($stmt->execute([$username, $hash])) {
        return "Registration successful!";
    } else {
        return "An error occurred during registration. Please try again.";
    }
}

function login($username, $password) {
    global $pdo;

    // Retrieve the user data based on the provided username
    $stmt = $pdo->prepare("SELECT id, password_hash, role FROM users WHERE username = ?");
    $stmt->execute([$username]);

    if ($user = $stmt->fetch(PDO::FETCH_ASSOC)) {
        // Verify the provided password against the hashed password in the database
        if (password_verify($password, $user['password_hash'])) {
            // Password is correct, start the session and set user data
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            return true;
        } else {
            return "Invalid password.";
        }
    }

    // Username doesn't exist
    return "Username not found.";
}

// Usage example:
// if (isset($_POST['register'])) { 
//    echo register($_POST['username'], $_POST['password']); 
// }
// if (isset($_POST['login'])) { 
//    echo login(...); 
// }
?>
