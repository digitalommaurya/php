<?php
session_start();
$dsn = 'mysql:host=localhost;dbname=ommaurya21_courses;charset=utf8mb4';
$pdo = new PDO($dsn, 'ommaurya21_lecture', 'Rscoe@1989', [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
]);
?>
