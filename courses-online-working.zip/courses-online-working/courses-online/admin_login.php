<?php
require 'auth.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $success = login($_POST['username'], $_POST['password']);
    if ($success && $_SESSION['role'] === 'admin') {
        header('Location: admin_courses.php');
        exit;
    } else {
        $message = "Access denied or incorrect credentials.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Login</title>
  <style>
    <?php include 'style.css'; ?>
  </style>
</head>
<body>
  <div class="form-container">
    <h2>Admin Login</h2>
    <?php if ($message): ?><p class="message"><?= $message ?></p><?php endif; ?>
    <form method="POST">
      <input type="text" name="username" placeholder="Admin Username" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit">Login</button>
    </form>
    <p><a href="login.php">Back to student login</a></p>
  </div>
</body>
</html>
