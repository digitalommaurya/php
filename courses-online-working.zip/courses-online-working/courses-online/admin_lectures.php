<?php
require 'db.php';

if ($_SESSION['role'] !== 'admin') {
    die('Access denied');
}

// Extract YouTube Video ID from any valid YouTube URL (including Shorts)
function getYouTubeVideoID($url) {
    $pattern = '%(?:youtube(?:-nocookie)?\.com/(?:shorts/|watch\?v=|embed/|v/)|youtu\.be/)([a-zA-Z0-9_-]{11})%i';
    if (preg_match($pattern, $url, $matches)) {
        return $matches[1];
    }
    return false;
}

// Handle Create or Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lecture_id = $_POST['lecture_id'] ?? null;
    $course_id = $_POST['course_id'];
    $title     = trim($_POST['title']);
    $video_url = trim($_POST['video_url'] ?? '');

    // Validate and embed YouTube
    $video_id = getYouTubeVideoID($video_url);
    if ($video_url && !$video_id) {
        die('Invalid YouTube URL.');
    }
    $videoEmbed = $video_id ? "https://www.youtube.com/embed/" . $video_id : null;

    // Handle PDF upload
    $pdfPath = null;
    if (!empty($_FILES['pdf']['tmp_name'])) {
        $pname = uniqid() . '_' . basename($_FILES['pdf']['name']);
        move_uploaded_file($_FILES['pdf']['tmp_name'], 'uploads/pdfs/' . $pname);
        $pdfPath = 'uploads/pdfs/' . $pname;
    } elseif ($lecture_id) {
        $stmt = $pdo->prepare("SELECT pdf_path FROM lectures WHERE id = ?");
        $stmt->execute([$lecture_id]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);
        $pdfPath = $existing['pdf_path'];
    }

    if ($lecture_id) {
        $stmt = $pdo->prepare("UPDATE lectures SET course_id = ?, title = ?, video_path = ?, pdf_path = ? WHERE id = ?");
        $stmt->execute([$course_id, $title, $videoEmbed, $pdfPath, $lecture_id]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO lectures (course_id, title, video_path, pdf_path) VALUES (?, ?, ?, ?)");
        $stmt->execute([$course_id, $title, $videoEmbed, $pdfPath]);
    }

    header('Location: admin_lectures.php');
    exit;
}

// Handle Delete
if (isset($_GET['delete_id'])) {
    $stmt = $pdo->prepare("DELETE FROM lectures WHERE id = ?");
    $stmt->execute([$_GET['delete_id']]);
    header('Location: admin_lectures.php');
    exit;
}

// Form values
$edit_mode = false;
$lecture_form = ['id'=>'', 'course_id'=>'', 'title'=>'', 'video_path'=>'', 'pdf_path'=>''];

if (isset($_GET['edit_id'])) {
    $stmt = $pdo->prepare("SELECT * FROM lectures WHERE id = ?");
    $stmt->execute([$_GET['edit_id']]);
    $lecture_form = $stmt->fetch(PDO::FETCH_ASSOC);
    $edit_mode = true;
}

// Fetch courses in order
$courses = $pdo->query("SELECT * FROM courses ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Lectures</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f7f7f7; }
        form { margin-bottom: 30px; background: #fff; padding: 20px; border-radius: 8px; }
        input, select { display: block; width: 100%; margin-top: 10px; padding: 8px; }
        button { margin-top: 10px; padding: 10px 15px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; }
        button:hover { background: #0056b3; }
        .lecture-list { background: #fff; padding: 20px; border-radius: 8px; }
        .lecture-item { margin-bottom: 15px; border-bottom: 1px solid #ddd; padding-bottom: 10px; }
        .actions a { margin-right: 10px; text-decoration: none; color: #007bff; }
        .actions a:hover { text-decoration: underline; }
        .course-section { border-top: 2px solid #ccc; padding-top: 15px; margin-top: 30px; }
    </style>
</head>
<body>
<a href="logout.php" style="float:right; color:red; font-size:16px;">🚪 Logout</a>
<h2><?= $edit_mode ? 'Edit Lecture' : 'Add New Lecture' ?></h2>
<form method="post" enctype="multipart/form-data">
    <input type="hidden" name="lecture_id" value="<?= htmlspecialchars($lecture_form['id']) ?>">

    <label>Course:</label>
    <select name="course_id" required>
        <option value="">-- Select Course --</option>
        <?php foreach ($courses as $c): ?>
            <option value="<?= $c['id'] ?>" <?= $c['id'] == $lecture_form['course_id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($c['title']) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label>Lecture Title:</label>
    <input name="title" value="<?= htmlspecialchars($lecture_form['title']) ?>" required>

    <label>YouTube Video URL (supports Shorts too):</label>
    <input type="url" name="video_url" value="<?= htmlspecialchars($lecture_form['video_path']) ?>" placeholder="https://www.youtube.com/watch?v=... or /shorts/...">

    <label>PDF Notes: <?= $lecture_form['pdf_path'] ? '(Leave blank to keep existing)' : '' ?></label>
    <input type="file" name="pdf" accept="application/pdf">

    <button type="submit"><?= $edit_mode ? 'Update' : 'Create' ?> Lecture</button>
    <?php if ($edit_mode): ?>
        <a href="admin_lectures.php">Cancel Edit</a>
    <?php endif; ?>
</form>

<div class="lecture-list">
    <h2>All Lectures by Course</h2>

    <?php foreach ($courses as $course): ?>
        <div class="course-section">
            <h3><?= htmlspecialchars($course['title']) ?></h3>

            <?php
            $stmt = $pdo->prepare("SELECT * FROM lectures WHERE course_id = ? ORDER BY id ASC");
            $stmt->execute([$course['id']]);
            $lectures = $stmt->fetchAll(PDO::FETCH_ASSOC);
            ?>

            <?php if (count($lectures) === 0): ?>
                <p style="color: #999;">No lectures yet for this course.</p>
            <?php else: ?>
                <?php foreach ($lectures as $l): ?>
                    <div class="lecture-item">
                        <strong><?= htmlspecialchars($l['title']) ?></strong><br>
                        <a href="view_lecture.php?id=<?= $l['id'] ?>">📺 View Lecture</a>
                        <div class="actions">
                            <a href="?edit_id=<?= $l['id'] ?>">✏️ Edit</a>
                            <a href="?delete_id=<?= $l['id'] ?>" onclick="return confirm('Delete this lecture?')">🗑️ Delete</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

</body>
</html>
