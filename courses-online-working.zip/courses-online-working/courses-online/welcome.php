<?php

session_start();

if(!isset($_SESSION['username']))
{

header("Location:error.php");

}

echo '

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Pyhton Whatsapp Lectures</title>
  <meta charset="utf-8">
  <meta name="description" content="Pyhton Whatsapp Lectures"> 
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  
</head>
<body>



<div class="container-fluid p-5 bg-primary text-white text-center">
  <h1> Learn Coding in Pyhton on Whatsapp Lectures </h1>
 
<a href="logout.php"  class="btn btn-success">Logout</a>


  <p>Complete all Lectures & Apply Practically To Improve your skills !</p> 
</div>
  
<div class="container mt-5">
  <div class="row">
    <div class="col-sm-4">
      <h3>Website design Basics</h3>
    
<p><button type="button" class="btn btn-outline-primary btn-block"><a href="lecture1.php">Lecture 1 -Html introduction</a></button>
<p><button type="button" class="btn btn-outline-primary btn-block"><a href="lecture2.php" target="_blank">Lecture 2 - Html headings</a></button>
<p><button type="button" class="btn btn-outline-primary btn-block"><a href="lecture3.php" target="_blank">Lecture 3 - "Html style attribute"</a></button>

      <p><button type="button" class="btn btn-outline-primary btn-block"><a href="lecture4.php">Lecture 4- "Html Text Formatting"</a></button>
<p><button type="button" class="btn btn-outline-primary btn-block"><a href="lecture5.php">Lecture 5- "Html List"</a></button>
<p><button type="button" class="btn btn-outline-primary btn-block"><a href="lecture6.php">Lecture 6- "Html Div Element"</a></button>
<p><button type="button" class="btn btn-outline-primary btn-block"><a href="lecture7.php">Lecture 7- "HTML TABLE"</a></button>
<p><button type="button" class="btn btn-outline-primary btn-block"><a href="lecture8.php">Lecture 8- "link one HTML page to another"</a></button>
<p><button type="button" class="btn btn-outline-primary btn-block"><a href="lecture9.php">Lecture 9- "Display Image in Html"</a></button>

<p><button type="button" class="btn btn-outline-primary btn-block"><a href="lecture10.php">Lecture 10- "Form in Html"</a></button>

</div>
    <div class="col-sm-4">
      <h3>Css flex and layout</h3>
	  <p><button type="button" class="btn btn-outline-primary btn-block"><a href="lecture11.php">Lecture 11- "Css introduction"</a></button>
       <p><button type="button" class="btn btn-outline-primary btn-block"><a href="lecture12.php">Lecture 11- "Css Flex"</a></button>
<p><button type="button" class="btn btn-outline-primary btn-block"><a href="https://geocities.ws/ommauryasir/full-stack/css/layout/" target="_blank">Lecture 11- "Css Flex Layout practice"</a></button>

	
</div>
    
  </div>
</div>

</body>

</html>

';




?>

