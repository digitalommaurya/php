<?php
require 'db.php';
if ($_SESSION['role'] !== 'admin') { die('Access denied'); }

// Initialize form values
$edit_mode = false;
$form_id = '';
$form_title = '';
$form_description = '';

// Handle Create or Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $title = $_POST['title'];
    $desc = $_POST['description'];
    
    if ($id) {
        // Update existing
        $stmt = $pdo->prepare("UPDATE courses SET title=?, description=? WHERE id=?");
        $stmt->execute([$title, $desc, $id]);
    } else {
        // Create new
        $stmt = $pdo->prepare("INSERT INTO courses (title, description) VALUES (?, ?)");
        $stmt->execute([$title, $desc]);
    }
    header('Location: admin_courses.php');
    exit;
}

// Handle Delete
if (isset($_GET['delete_id'])) {
    $stmt = $pdo->prepare("DELETE FROM courses WHERE id=?");
    $stmt->execute([$_GET['delete_id']]);
    header('Location: admin_courses.php');
    exit;
}

// Handle Edit
if (isset($_GET['edit_id'])) {
    $stmt = $pdo->prepare("SELECT * FROM courses WHERE id=?");
    $stmt->execute([$_GET['edit_id']]);
    $course = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($course) {
        $edit_mode = true;
        $form_id = $course['id'];
        $form_title = $course['title'];
        $form_description = $course['description'];
    }
}

// List courses
$courses = $pdo->query("SELECT * FROM courses")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Manage Courses</title>
  <style>
    body { font-family: Arial; padding: 20px; background: #f9f9f9; }
    form, ul { margin-top: 20px; }
    input, textarea { width: 100%; padding: 8px; margin: 6px 0; }
    button { padding: 10px 15px; background: #007bff; color: white; border: none; cursor: pointer; }
    button:hover { background: #0056b3; }
    .course-item { margin: 10px 0; }
    a { margin-left: 10px; color: #007bff; text-decoration: none; }
    a:hover { text-decoration: underline; }
  </style>
</head>
<body>
<h1>
<a href="admin_lectures.php" style="float:right; color:red; font-size:16px;">🚪 Add Lectures</a> 
<a href="admin_assign_courses.php" style="float:right; color:red; font-size:16px;">🚪 Assign Course</a>
<a href="logout.php" style="float:right; color:red; font-size:16px;">🚪 Logout</a>
</h1>

<h2><?= $edit_mode ? 'Edit Course' : 'Add New Course' ?></h2>

<form method="post">
  <input type="hidden" name="id" value="<?= htmlspecialchars($form_id) ?>">
  <input name="title" placeholder="Course Title" value="<?= htmlspecialchars($form_title) ?>" required>
  <textarea name="description" placeholder="Course Description" required><?= htmlspecialchars($form_description) ?></textarea>
  <button type="submit"><?= $edit_mode ? 'Update' : 'Create' ?> Course</button>
  <?php if ($edit_mode): ?>
    <a href="admin_courses.php">Cancel Edit</a>
  <?php endif; ?>
</form>

<h2>All Courses</h2>
<ul>
<?php foreach ($courses as $c): ?>
  <li class="course-item">
    <strong><?= htmlspecialchars($c['title']) ?></strong><br>
    <?= nl2br(htmlspecialchars($c['description'])) ?><br>
    <a href="?edit_id=<?= $c['id'] ?>">✏️ Edit</a>
    <a href="?delete_id=<?= $c['id'] ?>" onclick="return confirm('Delete this course?')">🗑️ Delete</a>
  </li>
<?php endforeach; ?>
</ul>

</body>
</html>
