<?php
require 'db.php';
session_start();

$message = '';

// Handle Registration
if (isset($_POST['register'])) {
    $username = trim($_POST['reg_username']);
    $password = $_POST['reg_password'];
    $role = $_POST['reg_role'];

    if ($username && $password && in_array($role, ['student', 'admin'])) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)");
        if ($stmt->execute([$username, $hash, $role])) {
            $message = "Registered successfully. You can now log in.";
        } else {
            $message = "Registration failed. Username might already exist.";
        }
    } else {
        $message = "Please fill in all registration fields.";
    }
}

// Handle Login
if (isset($_POST['login'])) {
    $username = trim($_POST['login_username']);
    $password = $_POST['login_password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];

        if ($user['role'] === 'admin') {
            header('Location: admin_courses.php');
        } else {
            header('Location: student_view.php');
        }
        exit;
    } else {
        $message = "Invalid login credentials.";
    }
}
?>
