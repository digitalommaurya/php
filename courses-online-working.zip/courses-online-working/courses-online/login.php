<?php
require 'auth.php';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $success = login($_POST['username'], $_POST['password']);
    if ($success) {
        if ($_SESSION['role'] === 'admin') {
            header('Location: admin_courses.php');
        } else {
            header('Location: student_view.php');
        }
        exit;
    } else {
        $message = "Login failed. Invalid username or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login</title>
  <style>
    <?php include 'style.css'; ?>
  </style>
</head>
<body>
  <div class="form-container">
    <h2>Login</h2>
    <?php if ($message): ?><p class="message"><?= $message ?></p><?php endif; ?>
    <form method="POST">
      <input type="text" name="username" placeholder="Username" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit">Login</button>
    </form>
    <p>No account? <a href="register.php">Register here</a></p>
  </div>
</body>
</html>
