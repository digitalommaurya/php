<?php
require 'db.php';
if ($_SESSION['role'] !== 'admin') die('Access denied');

// --- Handle Create or Update ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lecture_id = $_POST['lecture_id'] ?? null;
    $course_id = $_POST['course_id'];
    $title = $_POST['title'];

    // Get existing lecture if updating
    $videoPath = $pdfPath = null;
    if ($lecture_id) {
        $stmt = $pdo->prepare("SELECT * FROM lectures WHERE id = ?");
        $stmt->execute([$lecture_id]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);
        $videoPath = $existing['video_path'];
        $pdfPath = $existing['pdf_path'];
    }

    // Handle new file uploads
    if (!empty($_FILES['video']['tmp_name'])) {
        $vname = uniqid() . '_' . basename($_FILES['video']['name']);
        move_uploaded_file($_FILES['video']['tmp_name'], 'uploads/videos/' . $vname);
        $videoPath = 'uploads/videos/' . $vname;
    }
    if (!empty($_FILES['pdf']['tmp_name'])) {
        $pname = uniqid() . '_' . basename($_FILES['pdf']['name']);
        move_uploaded_file($_FILES['pdf']['tmp_name'], 'uploads/pdfs/' . $pname);
        $pdfPath = 'uploads/pdfs/' . $pname;
    }

    if ($lecture_id) {
        // UPDATE
        $stmt = $pdo->prepare("UPDATE lectures SET course_id=?, title=?, video_path=?, pdf_path=? WHERE id=?");
        $stmt->execute([$course_id, $title, $videoPath, $pdfPath, $lecture_id]);
    } else {
        // CREATE
        $stmt = $pdo->prepare("INSERT INTO lectures (course_id, title, video_path, pdf_path) VALUES (?, ?, ?, ?)");
        $stmt->execute([$course_id, $title, $videoPath, $pdfPath]);
    }

    header('Location: admin_lectures.php');
    exit;
}

// --- Handle Delete ---
if (isset($_GET['delete_id'])) {
    $stmt = $pdo->prepare("DELETE FROM lectures WHERE id = ?");
    $stmt->execute([$_GET['delete_id']]);
    header('Location: admin_lectures.php');
    exit;
}

// --- Handle Edit Mode ---
$edit_mode = false;
$lecture_form = ['id' => '', 'course_id' => '', 'title' => '', 'video_path' => '', 'pdf_path' => ''];

if (isset($_GET['edit_id'])) {
    $stmt = $pdo->prepare("SELECT * FROM lectures WHERE id = ?");
    $stmt->execute([$_GET['edit_id']]);
    $lecture_form = $stmt->fetch(PDO::FETCH_ASSOC);
    $edit_mode = true;
}

// --- Fetch courses and lectures ---
$courses = $pdo->query("SELECT * FROM courses")->fetchAll(PDO::FETCH_ASSOC);
$lectures = $pdo->query("
  SELECT l.*, c.title AS course_title 
  FROM lectures l 
  JOIN courses c ON l.course_id = c.id
  ORDER BY l.id DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Lectures</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f7f7f7; }
        form { margin-bottom: 30px; background: #fff; padding: 20px; border-radius: 8px; }
        input, select, textarea { display: block; width: 100%; margin-top: 10px; padding: 8px; }
        button { margin-top: 10px; padding: 10px 15px; background: #007bff; color: white; border: none; border-radius: 4px; }
        button:hover { background: #0056b3; }
        .lecture-list { background: #fff; padding: 20px; border-radius: 8px; }
        .lecture-item { margin-bottom: 15px; border-bottom: 1px solid #ddd; padding-bottom: 10px; }
        .actions a { margin-right: 10px; text-decoration: none; color: #007bff; }
        .actions a:hover { text-decoration: underline; }
    </style>
</head>
<body>

<h2><?= $edit_mode ? 'Edit Lecture' : 'Add New Lecture' ?></h2>
<form method="post" enctype="multipart/form-data">
    <input type="hidden" name="lecture_id" value="<?= htmlspecialchars($lecture_form['id']) ?>">
    
    <label>Course:</label>
    <select name="course_id" required>
        <option value="">-- Select Course --</option>
        <?php foreach ($courses as $c): ?>
            <option value="<?= $c['id'] ?>" <?= $c['id'] == $lecture_form['course_id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($c['title']) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label>Lecture Title:</label>
    <input name="title" value="<?= htmlspecialchars($lecture_form['title']) ?>" required>

    <label>Video File: <?= $lecture_form['video_path'] ? '(Leave blank to keep existing)' : '' ?></label>
    <input type="file" name="video" accept="video/*">

    <label>PDF Notes: <?= $lecture_form['pdf_path'] ? '(Leave blank to keep existing)' : '' ?></label>
    <input type="file" name="pdf" accept="application/pdf">

    <button type="submit"><?= $edit_mode ? 'Update' : 'Create' ?> Lecture</button>
    <?php if ($edit_mode): ?>
        <a href="admin_lectures.php">Cancel Edit</a>
    <?php endif; ?>
</form>

<div class="lecture-list">
    <h2>All Lectures</h2>
    <?php foreach ($lectures as $l): ?>
        <div class="lecture-item">
            <strong><?= htmlspecialchars($l['course_title']) ?> - <?= htmlspecialchars($l['title']) ?></strong><br>
            <?php /* if ($l['video_path']): ?>
                🎥 <a href="<?= htmlspecialchars($l['video_path']) ?>" target="_blank">Video</a>
            <?php endif; ?>
            <?php if ($l['pdf_path']): ?>
                📄 <a href="<?= htmlspecialchars($l['pdf_path']) ?>" target="_blank">PDF</a>
            <?php endif; */ ?>
			
			<a href="view_lecture.php?id=<?= $l['id'] ?>">📺 View Lecture</a>
            <div class="actions">
                <a href="?edit_id=<?= $l['id'] ?>">✏️ Edit</a>
                <a href="?delete_id=<?= $l['id'] ?>" onclick="return confirm('Delete this lecture?')">🗑️ Delete</a>
            </div>
        </div>
    <?php endforeach; ?>
</div>

</body>
</html>
