<?php
require 'db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    die("Access denied.");
}

$student_id = $_SESSION['user_id'];

// Get assigned courses
$stmt = $pdo->prepare("
    SELECT c.*
    FROM courses c
    JOIN student_courses sc ON c.id = sc.course_id
    WHERE sc.student_id = ?
");
$stmt->execute([$student_id]);
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch lectures for each assigned course
$course_lectures = [];
$lecture_stmt = $pdo->prepare("SELECT * FROM lectures WHERE course_id = ?");
foreach ($courses as $course) {
    $lecture_stmt->execute([$course['id']]);
    $course_lectures[$course['id']] = $lecture_stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Your Courses</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f9f9f9; }
        .course { background: #fff; padding: 20px; margin-bottom: 20px; border-radius: 6px; }
        .lecture { margin-left: 20px; padding: 10px 0; border-top: 1px solid #ddd; }
        .lecture a { margin-right: 10px; color: #007bff; text-decoration: none; }
        .lecture a:hover { text-decoration: underline; }
    </style>
</head>
<body>

<h1>Your Assigned Courses</h1>

<?php if (empty($courses)): ?>
    <p><em>No courses assigned yet. Please contact your admin.</em></p>
<?php else: ?>
    <?php foreach ($courses as $course): ?>
        <div class="course">
            <h2><?= htmlspecialchars($course['title']) ?></h2>
            <p><?= nl2br(htmlspecialchars($course['description'])) ?></p>

            <?php if (!empty($course_lectures[$course['id']])): ?>
                <?php foreach ($course_lectures[$course['id']] as $lecture): ?>
                    <div class="lecture">
                        <strong><?= htmlspecialchars($lecture['title']) ?></strong><br>
                        <a href="view_lecture1.php?id=<?= $lecture['id'] ?>">📺 View Lecture</a>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p><em>No lectures yet.</em></p>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

</body>
</html>
