<?php
session_start();

if(!isset($_SESSION['username']))
{

header("Location:error.php");

}
else 
{
	
	echo '
<!DOCTYPE html> 
<html> 
  
<head> 
    <title>PDF in HTML</title> 
</head> 
  
<body> 
<a href="welcome.php">Go to Main Page </a>
    <center> 
        <h1 style="color: green">First Day -Lecture 1</h1> 
        <h3>Introduction on Python Variable</h3> 
        <object data= 
"lecture1.pdf#toolbar=0" 
                width="100%"
                height=800> 
        </object> 
    </center> 
</body> 
  
</html>';

}?>
