<?php
require 'db.php';
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    die('Access denied');
}



if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Lecture ID missing or invalid.");
}

$lecture_id = (int)$_GET['id'];

$stmt = $pdo->prepare("
    SELECT l.*, c.title AS course_title 
    FROM lectures l
    JOIN courses c ON l.course_id = c.id
    WHERE l.id = ?
");
$stmt->execute([$lecture_id]);
$lecture = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$lecture) {
    die("Lecture not found.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Lecture: <?= htmlspecialchars($lecture['title']) ?></title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f4f4f4; }
        h1, h2, h3 { color: #333; }
        .content { background: white; padding: 20px; border-radius: 8px; max-width: 900px; margin: auto; }
        video, iframe { width: 100%; max-width: 800px; height: 400px; margin-top: 15px; border: 1px solid #ddd; border-radius: 4px; }
        a.back { display: inline-block; margin-top: 20px; text-decoration: none; color: #007bff; }
        a.back:hover { text-decoration: underline; }
    </style>
</head>
<body>
<h1>Courses and Lectures 
    <a href="logout.php" style="float:right; color:red; font-size:16px;">🚪 Logout</a>
</h1>

<div class="content">
    <h1><?= htmlspecialchars($lecture['title']) ?></h1>
    <h3>Course: <?= htmlspecialchars($lecture['course_title']) ?></h3>

    <?php if (!empty($lecture['video_path'])): ?>
        <h2>Video Lecture</h2>
        <video controls>
            <source src="<?= htmlspecialchars($lecture['video_path']) ?>" type="video/mp4">
            Your browser does not support the video tag.
        </video>
    <?php endif; ?>

    <?php if (!empty($lecture['pdf_path'])): ?>
        <h2>PDF Notes</h2>
        <iframe src="<?= htmlspecialchars($lecture['pdf_path']) ?>"></iframe>
    <?php endif; ?>

    <a class="back" href="admin_lectures.php">← Back to Lectures</a>
</div>

</body>
</html>
