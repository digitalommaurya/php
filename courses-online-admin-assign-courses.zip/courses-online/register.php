<?php
require 'auth.php'; // the code you shared
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $success = register($_POST['username'], $_POST['password']);
    if ($success) {
        $message = "Registration successful. <a href='login.php'>Login here</a>.";
    } else {
        $message = "Registration failed. Username may already exist.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Student Registration</title>
  <style>
    <?php include 'style.css'; ?>
  </style>
</head>
<body>
  <div class="form-container">
    <h2>Register</h2>
    <?php if ($message): ?><p class="message"><?= $message ?></p><?php endif; ?>
    <form method="POST">
      <input type="text" name="username" placeholder="Username" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit">Register</button>
    </form>
    <p>Already have an account? <a href="login.php">Login</a></p>
  </div>
</body>
</html>
