<?php
require 'db.php';

function register($username, $password) {
    global $pdo;
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'student')");
    return $stmt->execute([$username, $hash]);
}

function login($username, $password) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT id, password_hash, role FROM users WHERE username = ?");
    $stmt->execute([$username]);
    if ($user = $stmt->fetch(PDO::FETCH_ASSOC)) {
        if (password_verify($password, $user['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            return true;
        }
    }
    return false;
}

// Usage example:
// if (isset($_POST['register'])) { register($_POST['username'], $_POST['password']); }
// if (isset($_POST['login'])) { login(...)? redirect accordingly }
?>
