<?php
require 'auth.php';



$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Manually register with admin role
    global $pdo;
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'admin')");
    try {
        $stmt->execute([$username, $hash]);
        $message = "New admin created successfully.";
    } catch (PDOException $e) {
        $message = "Error: Username might already exist.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Create New Admin</title>
  <style>
    <?php include 'style.css'; ?>
  </style>
</head>
<body>
  <div class="form-container">
    <h2>Create Admin</h2>
    <?php if ($message): ?><p class="message"><?= $message ?></p><?php endif; ?>
    <form method="POST">
      <input type="text" name="username" placeholder="Admin Username" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit">Create Admin</button>
    </form>
    <p><a href="admin_courses.php">Back to Admin Panel</a></p>
  </div>
</body>
</html>
