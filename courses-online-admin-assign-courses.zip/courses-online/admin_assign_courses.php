<?php
require 'db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die('Access denied');
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['student_id'])) {
    $student_id = (int)$_POST['student_id'];

    // Remove existing assignments
    $stmt = $pdo->prepare("DELETE FROM student_courses WHERE student_id = ?");
    $stmt->execute([$student_id]);

    // Add new assignments
    if (isset($_POST['course_ids']) && is_array($_POST['course_ids'])) {
        $stmt = $pdo->prepare("INSERT INTO student_courses (student_id, course_id) VALUES (?, ?)");
        foreach ($_POST['course_ids'] as $course_id) {
            $stmt->execute([$student_id, (int)$course_id]);
        }
    }

    $message = "Courses updated successfully for the student.";
}

// Fetch students (only students, not admins)
$students = $pdo->query("SELECT * FROM users WHERE role = 'student'")->fetchAll(PDO::FETCH_ASSOC);

// Fetch all courses
$courses = $pdo->query("SELECT * FROM courses")->fetchAll(PDO::FETCH_ASSOC);

// If a student is selected (for editing)
$selected_student_id = isset($_GET['student_id']) ? (int)$_GET['student_id'] : null;
$assigned_courses = [];

if ($selected_student_id) {
    $stmt = $pdo->prepare("SELECT course_id FROM student_courses WHERE student_id = ?");
    $stmt->execute([$selected_student_id]);
    $assigned_courses = $stmt->fetchAll(PDO::FETCH_COLUMN);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Assign Courses to Students</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 6px rgba(0,0,0,0.1); }
        h2 { margin-bottom: 20px; }
        select, button { padding: 10px; margin: 10px 0; width: 100%; }
        .checkboxes label { display: block; margin: 5px 0; }
        .message { background: #d4edda; color: #155724; padding: 10px; border-radius: 4px; margin-bottom: 20px; }
        .back-link { display: inline-block; margin-top: 20px; text-decoration: none; color: #007bff; }
        .back-link:hover { text-decoration: underline; }
    </style>
</head>
<body>

<div class="container">
    <h2>Assign Courses to Students</h2>

    <?php if (isset($message)): ?>
        <div class="message"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <form method="get" action="">
        <label for="student_id">Select Student:</label>
        <select name="student_id" id="student_id" onchange="this.form.submit()">
            <option value="">-- Choose a student --</option>
            <?php foreach ($students as $student): ?>
                <option value="<?= $student['id'] ?>" <?= $selected_student_id == $student['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($student['username']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </form>

    <?php if ($selected_student_id): ?>
        <form method="post">
            <input type="hidden" name="student_id" value="<?= $selected_student_id ?>">
            <div class="checkboxes">
                <label><strong>Assign Courses:</strong></label>
                <?php foreach ($courses as $course): ?>
                    <label>
                        <input
                            type="checkbox"
                            name="course_ids[]"
                            value="<?= $course['id'] ?>"
                            <?= in_array($course['id'], $assigned_courses) ? 'checked' : '' ?>
                        >
                        <?= htmlspecialchars($course['title']) ?>
                    </label>
                <?php endforeach; ?>
            </div>
            <button type="submit">Save Assignments</button>
        </form>
    <?php endif; ?>

    <a class="back-link" href="admin_courses.php">← Back to Admin Panel</a>
</div>

</body>
</html>
