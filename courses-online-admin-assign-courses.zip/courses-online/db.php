<?php
session_start();
$dsn = 'mysql:host=localhost;dbname=elearning;charset=utf8mb4';
$pdo = new PDO($dsn, 'root', '', [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
]);
?>
