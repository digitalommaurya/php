<?php
require 'db.php';
session_start();
session_unset();
session_destroy();
header('Location: login.php'); // redirect to your login/register page
exit;



?>
